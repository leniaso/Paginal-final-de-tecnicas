-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	11.3.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bankaccount`
--

DROP TABLE IF EXISTS `bankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bankaccount` (
  `AccountNumber` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identificador unico de la tabla BankAccount',
  `Money` double DEFAULT NULL COMMENT 'plata con la que se cuenta',
  `Transactions` text DEFAULT NULL COMMENT 'Transacciones que se han realizado',
  `AccountState` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Estado de la cuenta',
  `TypeOfState` varchar(100) DEFAULT 'valido' COMMENT 'En el caso de que AccountState fuera falso, esta guardaria la razon del porque',
  `LastAccess` date DEFAULT NULL COMMENT 'se muestra cual fue el utimo acceso a la cuenta de banco',
  PRIMARY KEY (`AccountNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankaccount`
--

LOCK TABLES `bankaccount` WRITE;
/*!40000 ALTER TABLE `bankaccount` DISABLE KEYS */;
INSERT INTO `bankaccount` VALUES (1,138980598.97,'Se consigno el 2024-06-03 una cantidad de 1.5424E8 pesos. \r\nSe retiro el 2024-06-03 una cantidad de 2000.0 pesos\n se retiro el 2024-06-03 una cantidad de 30000.0 pesos\n \nSe retiro el 2024-06-03 una cantidad de 2.0000001E7 pesos. \n ',1,'valido','2024-06-04'),(2,15000000,NULL,1,'valido',NULL),(3,5000000,NULL,1,'valido',NULL),(4,48500,'Se consigno el 2024-06-03 una cantidad de 50000.0 pesos. ',1,'valido','2024-06-04');
/*!40000 ALTER TABLE `bankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centralbank`
--

DROP TABLE IF EXISTS `centralbank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centralbank` (
  `NumClients` int(11) DEFAULT NULL COMMENT 'Numero de clientes atendidos',
  `ClientsServed` text DEFAULT NULL COMMENT 'Cuales clientes fueron atendidos',
  `Withdrawals` double DEFAULT NULL COMMENT 'Cantidad de dinero que fue retirado',
  `Profits` double DEFAULT NULL COMMENT 'Ganancias del banco',
  `IdBank` varchar(100) NOT NULL COMMENT 'Identificador del banco',
  `Policies` text NOT NULL COMMENT 'Politicas que tendra el banco',
  `BankName` varchar(100) NOT NULL COMMENT 'Nombre del banco',
  `AdminPassword` varchar(100) NOT NULL COMMENT 'Contraseña para entrar la persona encontrada del banco',
  PRIMARY KEY (`IdBank`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centralbank`
--

LOCK TABLES `centralbank` WRITE;
/*!40000 ALTER TABLE `centralbank` DISABLE KEYS */;
INSERT INTO `centralbank` VALUES (4,'Rosalia consigno  1.5424E8 el 2024-06-03\r\n. Rosalia retiro  2000.0 el 2024-06-03\r\n. Rosalia retiro  30000.0 el 2024-06-03',20030001,600900.03,'906041235','Políticas del banco. \r\n\r\npolítica 1: para poder retirar una suma mayor a 20 millones \r\nse debe dar la contraseña de emergencia que coloco al \r\nmomento de registrarse. \r\n\r\npolítica 2: nuestro banco no tendrá cuota de manejo \r\nA cambio, tendrá un impuesto por cada consignación y/o\r\nretiro de un 3%. \r\n\r\npolítica 3: El encargado del banco podrá enbargarlo\r\ny/o cancelar su cuenta de banco en cualquier momento.\r\nsi lo ve necesario, y solo él podrá retirar ese\r\nestado. \r\n\r\npolítica 4: si su cuenta se encuentra en estado de\r\nembargado y/o cancelado no podrá realizar ninguna\r\nOperación en su cuenta, (además de mirar el saldo).\r\n \r\nSomos un banco que siempre buscará darle el mejor \r\nservicio a nuestros clientes.  ','BancoStar','342584390323');
/*!40000 ALTER TABLE `centralbank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `Id` varchar(100) NOT NULL COMMENT 'Identificador de la tabla  Client',
  `Name` varchar(100) NOT NULL COMMENT 'Nombre del cliente',
  `LastName` varchar(100) DEFAULT NULL COMMENT 'Apellido del cliente',
  `Password` int(11) NOT NULL COMMENT 'Contraseña del cliente',
  `AccountNumber` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Hace referencia al numero de identificaion de la cuenta de banco',
  `EmergencyPassword` varchar(100) NOT NULL COMMENT 'clave de emergencia en caso de retiros muy grandes',
  PRIMARY KEY (`Id`),
  KEY `client_BankAccount_FK` (`AccountNumber`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES ('1015689','Rosalia','Vila',6740,1,'papichulo1'),('213324d','pepito','perez',1234,4,'alpinito'),('3590123','Justin','Bieber',3312,2,'nomames'),('604322','Shakira','Mebarak',1290,3,'seriamente');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bank'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-04  5:31:27
