document.getElementById('loginForm').addEventListener('submit', validateForm);

function validateForm(event) {
    event.preventDefault();

    var userId = document.getElementById("user").value;
    var password = document.getElementById("password").value;

    $.ajax({
        type: "POST",
        url: "login",
        data: {User: userId, password: password},
        success: function (response) {
            if (response.trim() === "success") {
                callservlet(userId);
                window.location.href = "AccountInformation.jsp";
            } else {
                alert("Invalid user ID or password.");
                document.getElementById("user").value = "";
                document.getElementById("password").value = "";
            }
        },
        error: function (xhr, status, error) {
            console.error("Error in AJAX request:", status, error);
        }
    });
}

async function callservlet(userId) {
    try {
        const response = await fetch('api/accountserv?id=' + userId);
        const data = await response.json();
        if (response.ok) {
            alert('Usuario autenticado exitosamente.');
        } else {
            alert('Error al autenticar usuario: ' + data.error);
        }
    } catch (error) {
        console.error('Hubo un problema con la operación de autenticación del usuario:', error);
    }
}

