function realizarOperaciones() {
    
    window.location.href = 'operations.jsp';
}

