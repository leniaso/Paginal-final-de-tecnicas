document.getElementById('loginForm').addEventListener('submit', validateForm);

function validateForm(event) {
    event.preventDefault();

    var idBank = document.getElementById("user").value;
    var password = document.getElementById("password").value;

    $.ajax({
        type: "POST",
        url: "loginAdmin",
        data: {User: idBank, password: password},
        success: function (response) {
            if (response.trim() === "success") {
                callservlet(idBank);
                window.location.href = "BankInformation.jsp";
            } else {
                alert("Invalid user ID or password.");
                document.getElementById("user").value = "";
                document.getElementById("password").value = "";
            }
        },
        error: function (xhr, status, error) {
            console.error("Error in AJAX request:", status, error);
        }
    });
}

async function callservlet(idBank) {
    try {
        const response = await fetch('api/bankserv?idBank=' + idBank);
        const data = await response.json();
        if (response.ok) {
            alert('Usuario autenticado exitosamente.');
        } else {
            alert('Error al autenticar usuario: ' + data.error);
        }
    } catch (error) {
        console.error('Hubo un problema con la operación de autenticación del usuario:', error);
    }
}

