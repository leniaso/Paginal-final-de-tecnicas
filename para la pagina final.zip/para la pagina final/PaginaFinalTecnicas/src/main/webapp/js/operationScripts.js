var selectedCurrency = "pesos";
var operation=null;

function selectCurrency(currency) {
    selectedCurrency = currency;
    alert("Moneda seleccionada: " + selectedCurrency);
}

function volver() {
  window.location.href = 'Index.jsp';
}

function verificarCantidad() {
            let cantidad = document.getElementById('retirar').value;
            if (parseInt(cantidad) > 20000000) {
                document.getElementById('secret-password-container').style.display = 'block';
            } else {
                document.getElementById('secret-password-container').style.display = 'none';
            }
        }
        
function realizarOperacion(tipo, accountNumber) {
    let cantidad = 0;
    if (tipo === 'retirar') {
        cantidad = document.getElementById('retirar').value;
        if (isNaN(cantidad) || cantidad.trim() === "") {
            alert('Por favor, ingrese una cantidad válida.');
            return;
        }
        cantidad = parseInt(cantidad);
        if (cantidad > 20000000) {
            let emergencyPassword = document.getElementById('emergencyPassword').value;
            if (emergencyPassword === '') {
                alert('Por favor, ingrese la contraseña secreta.');
                return;
            }
        }
    } else if (tipo === 'consignar') {
        cantidad = document.getElementById('consignar').value;
        if (isNaN(cantidad) || cantidad.trim() === "") {
            alert('Por favor, ingrese una cantidad válida.');
            return;
        }
        cantidad = parseInt(cantidad);
    }

    let operationData = {
        operation: tipo,
        currency: selectedCurrency,
        amount: cantidad,
        accountNumber: accountNumber,
        emergencyPassword: tipo === 'retirar' && cantidad > 20000000 ? document.getElementById('emergencyPassword').value : null
    };

    fetch('api/opera', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(operationData)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
    })
    .catch(error => console.error('Error:', error));
}
