function ejecutarAccion() {
    var accountNumber = document.getElementById("accountNumber").value.trim(); 
    if (accountNumber !== "") { 
        var state = null; 
        var botonPresionado = event.target.textContent.trim(); 
        switch (botonPresionado) { 
            case "Validar":
                state = "valido";
                break;
            case "Embargar":
                state = "embargado";
                break;
            case "Cancelar":
                state = "cancelado";
                break;
            default:
                console.error("Botón desconocido");
                return;
        }

        var url = `modifierserv?state=${state}&accountNumber=${accountNumber}`;
        fetch(url, {
            method: "GET"
        }).then(response => {
            if (response.ok) {
                return response.json(); // Parsear la respuesta a JSON
            } else {
                console.error("Error al ejecutar la acción");
            }
        }).then(data => {
            if (data.isValid) {
                console.log("Acción ejecutada exitosamente");
                // Aquí puedes actualizar el JSP según sea necesario
            } else {
                console.error("Error al ejecutar la acción");
            }
        }).catch(error => {
            console.error("Error:", error);
        });
    } else {
        console.error("El placeholder está vacío");
    }
}

document.querySelectorAll(".buttons-container button").forEach(button => {
    button.addEventListener("click", ejecutarAccion);
});