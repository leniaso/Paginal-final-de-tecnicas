/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Beans;

/**
 *
 * @author Alejandro
 */
public class Clients {
    private String id;
    private String name;
    private String Lastname;
    private String Password;
    private int AccountNumber;
    private String EmergencyPassword;

    public Clients() {
    }

    public Clients(String id, String name, String Lastname, String Password, int AccountNumber, String EmergencyPassword) {
        this.id = id;
        this.name = name;
        this.Lastname = Lastname;
        this.Password = Password;
        this.AccountNumber = AccountNumber;
        this.EmergencyPassword = EmergencyPassword;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(int AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    public String getEmergencyPassword() {
        return EmergencyPassword;
    }

    public void setEmergencyPassword(String EmergencyPassword) {
        this.EmergencyPassword = EmergencyPassword;
    }
    
    
    
    
}
