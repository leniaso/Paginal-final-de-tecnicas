/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Beans;

public class CentralBank {

    private String idBank;
    private int numClients;
    private String clientsServed;
    private double withdrawals;
    private double profits;
    private String adminPassword;

    public CentralBank() {
    }

    public CentralBank(String idBank, int numClients, String clientsServed, double withdrawals, double profits, String adminPassword) {
        this.idBank = idBank;
        this.numClients = numClients;
        this.clientsServed = clientsServed;
        this.withdrawals = withdrawals;
        this.profits = profits;
        this.adminPassword = adminPassword;
    }

    public String getIdBank() {
        return idBank;
    }

    public void setIdBank(String idBank) {
        this.idBank = idBank;
    }

    public int getNumClients() {
        return numClients;
    }

    public void setNumClients(int numClients) {
        this.numClients = numClients;
    }

    public String getClientsServed() {
        return clientsServed;
    }

    public void setClientsServed(String clientsServed) {
        this.clientsServed = clientsServed;
    }

    public double getWithdrawals() {
        return withdrawals;
    }

    public void setWithdrawals(double withdrawals) {
        this.withdrawals = withdrawals;
    }

    public double getProfits() {
        return profits;
    }

    public void setProfits(double profits) {
        this.profits = profits;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

}
