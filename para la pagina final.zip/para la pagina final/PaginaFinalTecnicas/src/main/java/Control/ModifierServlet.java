package Control;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

@WebServlet("/modifierserv")
public class ModifierServlet extends HttpServlet {

   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Obtener los parámetros de la solicitud GET
        String state = request.getParameter("state");
        String accountNumParam = request.getParameter("accountNumber");
        int accNum = 0;
        try {
            accNum = Integer.parseInt(accountNumParam);
        } catch (NumberFormatException e) {
            // Manejar el caso en el que el accountNumber no es un número válido
        }

        boolean isValid = DBInformation.modifierState(state, accNum);

        // Crear un JSONObject para la respuesta
        JSONObject responseJson = new JSONObject();
        responseJson.put("isValid", isValid);

        // Establecer el tipo de contenido y el encoding de la respuesta
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Escribir la respuesta JSON
        try (PrintWriter out = response.getWriter()) {
            out.write(responseJson.toString());
        }
    }
}