package Control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import javax.servlet.annotation.MultipartConfig;
import Beans.CentralBank;

@WebServlet("/api/bankserv")
@MultipartConfig
public class BankServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(AccountServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idBank = request.getParameter("idBank");
        CentralBank bank = DBInformation.getBankInfo(idBank);
        if (bank != null) {
            HttpSession session = request.getSession();
            session.setAttribute("bank", bank);

            RequestDispatcher dispatcher = request.getRequestDispatcher("BankInformation.jsp");
            dispatcher.forward(request, response);
        } else {
            logger.log(Level.WARNING, "No bank  found for idBank number: {0}", idBank);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"error\":\"No bank found.\"}");
        }

    }
}
