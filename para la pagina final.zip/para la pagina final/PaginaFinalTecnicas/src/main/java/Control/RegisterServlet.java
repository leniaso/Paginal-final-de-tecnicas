/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Beans.Clients;
import javax.servlet.annotation.WebServlet;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String lastName = request.getParameter("lastName");
        String password = request.getParameter("password");
        String emergencyPassword = request.getParameter("emergencyPassword");

        if (id.isEmpty() || name.isEmpty() || lastName.isEmpty() || password.isEmpty() || emergencyPassword.isEmpty() || !password.matches("\\d{4}")) {
            response.setContentType("text/html");
            response.getWriter().println("<script>alert('Por favor complete todos los campos y asegúrese de que la contraseña sea un número de 4 dígitos'); history.back();</script>");
            return;
        }
        Clients client = new Clients(id, name, lastName, password, 0, emergencyPassword);
        DBInformation.RegisterClient(client);
        response.setContentType("text/html");
        response.getWriter().println("<script>alert('Registro exitoso'); location.href='Index.jsp';</script>");
    }
}
