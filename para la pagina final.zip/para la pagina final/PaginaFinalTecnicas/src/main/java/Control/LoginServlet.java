/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import javax.servlet.annotation.MultipartConfig;

@WebServlet("/login")
@MultipartConfig
public class LoginServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LoginServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userId = request.getParameter("User");
        int password;

        try {
            password = Integer.parseInt(request.getParameter("password"));
        } catch (NumberFormatException e) {
            logger.log(Level.SEVERE, "Error parsing password to integer", e);
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid password format");
            return;
        }

        boolean isValid = DBInformation.validateUser(userId, password);

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        if (isValid) {
            HttpSession session = request.getSession();
            session.setAttribute("userId", userId);
            logger.log(Level.INFO, "User ID set in session: {0}", userId);
            response.getWriter().write("success");
        } else {
            response.getWriter().write("error");
        }

    }
}