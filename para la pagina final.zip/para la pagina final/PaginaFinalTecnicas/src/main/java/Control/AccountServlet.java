/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Beans.BankAccounts;
import java.io.IOException;
import javax.servlet.annotation.MultipartConfig;

@WebServlet(name= "AccountServlet ", urlPatterns= "/api/accountserv")
@MultipartConfig
public class AccountServlet extends HttpServlet {
    
     private static final Logger logger = Logger.getLogger(AccountServlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("id");

        int accountNumber = DBInformation.getAccNumber(userId);
        
        String name = DBInformation.getName(userId);

        logger.log(Level.INFO, "AccountNumber retrieved: {0}", accountNumber);

        BankAccounts bankAccount = DBInformation.getAccountinfo(accountNumber);

        if (bankAccount != null) {
            HttpSession session = request.getSession();
            session.setAttribute("bankAccount", bankAccount);
            session.setAttribute("name", name);
            session.setAttribute("accountNumber", accountNumber);

            RequestDispatcher dispatcher = request.getRequestDispatcher("AccountInformation.jsp");
            dispatcher.forward(request, response);
        } else {
            logger.log(Level.WARNING, "No bank account found for account number: {0}", accountNumber);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"error\":\"No bank account found.\"}");
        }
    }
}