package Control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import javax.servlet.annotation.MultipartConfig;

@WebServlet("/loginAdmin")
@MultipartConfig
public class AdminLogServlet extends HttpServlet {

    private static final Logger logger = Logger.getLogger(LoginServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String idBank = request.getParameter("User");
        String password = request.getParameter("password");

        boolean isValid = DBInformation.validateAdmin(idBank, password);

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        if (isValid) {
            HttpSession session = request.getSession();
            session.setAttribute("IdBank", idBank);
            logger.log(Level.INFO, "User ID set in session: {0}", idBank);
            response.getWriter().write("success");
        } else {
            response.getWriter().write("error");
        }

    }

}
