/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.sql.Date;
import java.time.LocalDate;
import model.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Beans.*;

public class DBInformation {

    public static boolean validateUser(String id, int password) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT password FROM client WHERE Id = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, id);
            results = statement.executeQuery();

            if (results.next()) {
                int pass = results.getInt("password");
                return pass == password;
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

        return false;
    }

    public static String getPolicies() {
        String IdBank = "906041235";
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String policies = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT Policies FROM centralbank WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, IdBank);
            results = statement.executeQuery();

            if (results.next()) {
                policies = results.getString("Policies");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return policies;
    }

    public static int getAccNumber(String id) {
        int AccountNumber = 0;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT AccountNumber FROM client WHERE Id = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, id);
            results = statement.executeQuery();

            if (results.next()) {
                AccountNumber = results.getInt("AccountNumber");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return AccountNumber;
    }

    public static BankAccounts getAccountinfo(int accountNumber) {
        updateDate(accountNumber);
        BankAccounts bankAccount = null;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT * FROM bankaccount WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();

            if (results.next()) {
                bankAccount = new BankAccounts();
                bankAccount.setAccountNumber(results.getInt("AccountNumber"));
                bankAccount.setMoney(results.getInt("Money"));
                bankAccount.setTransactions(results.getString("Transactions"));
                bankAccount.setAccountState(results.getBoolean("AccountState"));
                bankAccount.setTypeState(results.getString("TypeofState"));
                bankAccount.setLastAccess(results.getDate("LastAccess"));
                bankAccount.setDebt(results.getInt("Debt"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return bankAccount;
    }

    public static String getName(String id) {
        String name = "";
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT Name FROM client WHERE Id = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, id);
            results = statement.executeQuery();

            if (results.next()) {
                name = results.getString("Name");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return name;
    }

    public static void RegisterClient(Clients client) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "INSERT INTO client (Id, Name, LastName, Password, EmergencyPassword) VALUES (?, ?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);

            statement.setString(1, client.getId());
            statement.setString(2, client.getName());
            statement.setString(3, client.getLastname());
            statement.setString(4, client.getPassword());
            statement.setString(5, client.getEmergencyPassword());
            statement.executeUpdate();
            createAccount();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

    }

    private static void closeResources(Connection conn, PreparedStatement statement, ResultSet results) {
        try {
            if (results != null) {
                results.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (conn != null) {
                ConnectionDB.closeConnection(conn);
            }
        } catch (SQLException e) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    private static void createAccount() {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "INSERT INTO bankaccount (Money, Transactions, LastAccess) VALUES (NULL, NULL,NULL)";
            statement = conn.prepareStatement(sql);
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

    }

    private static void updateDate(int accountNumber) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        LocalDate Today = LocalDate.now();
        Date datenow = Date.valueOf(Today);
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "UPDATE bankaccount SET LastAccess = ? WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setDate(1, datenow);
            statement.setInt(2, accountNumber);
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

    }

    public static void Consign(int accountNumber, double consignment, String currency) {
        String action = "Se consigno";
        String id = getIDByAccNumber(accountNumber);
        String lastTransaction = getTransaction(accountNumber);
        consignment = convertMoney(consignment, currency);
        String transaction = latestTransactions(accountNumber, consignment, action);
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        double total = manageConsign(consignment, accountNumber);
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "UPDATE bankaccount SET Money = ?,Transactions=? WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setDouble(1, total);
            if (lastTransaction != null) {
                lastTransaction += "\n" + transaction;
                lastTransaction += "\n ";
                statement.setString(2, lastTransaction);
            } else {
                statement.setString(2, transaction);
            }
            statement.setInt(3, accountNumber);
            statement.executeUpdate();
            UpdateBankConsignment(id, consignment, accountNumber);

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
    }

    public static double retire(int accountNumber, double withdraw, String currency) {
        String action = "Se retiro";
        String id = getIDByAccNumber(accountNumber);
        String lastTransaction = getTransaction(accountNumber);
        withdraw = convertMoney(withdraw, currency);
        String transaction = latestTransactions(accountNumber, withdraw, action);
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        double total = manageRetire(withdraw, accountNumber);
        if (total < 0) {
            return total;
        } else {
            try {
                conn = ConnectionDB.getConnectionDB();
                String sql = "UPDATE bankaccount SET Money = ?,Transactions=? WHERE AccountNumber = ?";
                statement = conn.prepareStatement(sql);
                statement.setDouble(1, total);
                if (lastTransaction != null) {
                    lastTransaction += "\n" + transaction;
                    lastTransaction += "\n ";
                    statement.setString(2, lastTransaction);

                } else {
                    statement.setString(2, transaction);
                }
                statement.setInt(3, accountNumber);
                statement.executeUpdate();
                UpdateBankRetirements(id, withdraw, accountNumber);

            } catch (SQLException ex) {
                Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                closeResources(conn, statement, results);
            }
        }
        return total;
    }

    private static double getMoney(int accountNumber) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        double money = 0;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT Money FROM bankaccount WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();
            if (results.next()) {
                money = results.getInt("Money");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return money;
    }

    private static String getDate(int accountNumber) {
        String dateStr = null;
        Date date = null;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT LastAccess FROM bankaccount WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();
            if (results.next()) {
                date = results.getDate("LastAccess");
            }
            dateStr = date.toString();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return dateStr;
    }

    private static String latestTransactions(int accountNumber, double money, String action) {
        String date = getDate(accountNumber);
        String actualTransaction = action + " el " + date + " una cantidad de " + money + " pesos. ";

        return actualTransaction;
    }

    private static String getTransaction(int accountNumber) {
        String transaction = null;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT Transactions FROM bankaccount WHERE AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();
            if (results.next()) {
                transaction = results.getString("Transactions");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return transaction;

    }

    private static double manageRetire(double retire, int accountNumber) {
        double actmoney = getMoney(accountNumber);
        double tax;
        if (retire < 50000) {
            tax = 100;
        } else {
            tax = retire * 0.03;
        }
        double total = actmoney - retire - tax;
        return total;
    }

    private static double manageConsign(double consignment, int accountNumber) {
        double actMoney = getMoney(accountNumber);
        double tax;
        if (consignment < 50000 && consignment > 0) {
            tax = 100;
        } else {
            tax = consignment * 0.03;
        }
        double total = actMoney + consignment - tax;
        return total;
    }

    private static double convertMoney(double money, String currency) {
        double convertedMoney;
        if (currency.equals("Dolares")) {
            convertedMoney = money * (3856);
            return convertedMoney;
        } else if (currency.equals("Euros")) {
            convertedMoney = money * (4202);
            return convertedMoney;
        }
        return money;
    }

    public static String getIDByAccNumber(int accountNumber) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String clientID = " ";
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT client.Id "
                    + "FROM client "
                    + "INNER JOIN bankaccount ON client.AccountNumber = bankaccount.AccountNumber "
                    + "WHERE bankaccount.AccountNumber = ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();
            if (results.next()) {
                clientID = results.getString("Id");

            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return clientID;
    }

    public static String getEmergencyPassword(String Id) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String emerPass = " ";
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT EmergencyPassword FROM client WHERE Id = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, Id);
            results = statement.executeQuery();
            if (results.next()) {
                emerPass = results.getString("EmergencyPassword");
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return emerPass;

    }

    public static void UpdateBankRetirements(String id, double amount, int accountNumber) {
        String IdBank = "906041235";
        String date = getDate(accountNumber);
        String clientsServed = getClientsServed(IdBank);
        String operation = "retiro ";
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String name = getName(id);
        String clientOperation = name + " " + operation + " " + amount + " el " + date + ".     ";
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "UPDATE centralbank SET NumClients = NumClients + 1, ClientsServed = ?, Withdrawals = Withdrawals + ?, Profits = Profits + ? WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);

            if (clientsServed == null) {
                statement.setString(1, clientOperation);
            } else {
                clientsServed += "\n" + clientOperation;
                clientsServed += "\n";
                statement.setString(1, clientsServed);

            }
            statement.setDouble(2, amount);
            double profits = amount * (0.03);
            statement.setDouble(3, profits);
            statement.setString(4, IdBank);
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
    }

    public static void UpdateBankConsignment(String id, double amount, int accountNumber) {
        String IdBank = "906041235";
        String date = getDate(accountNumber);
        String clientsServed = getClientsServed(IdBank);
        String operation = "consigno ";
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String name = getName(id);
        String clientOperation = name + " " + operation + " " + amount + " el " + date + ".      ";
        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "UPDATE centralbank SET NumClients = NumClients + 1, ClientsServed = ?, Profits = Profits + ? WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);

            if (clientsServed == null) {
                statement.setString(1, clientOperation);
            } else {
                clientsServed += "\n" + clientOperation;
                clientsServed += "\n";
                statement.setString(1, clientsServed);
            }

            statement.setDouble(2, amount);
            double profits = amount * 0.03;
            statement.setDouble(3, profits);
            statement.setString(4, IdBank);
            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
    }

    public static String getClientsServed(String IdBank) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String ClientsServed = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT ClientsServed FROM centralbank WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, IdBank);
            results = statement.executeQuery();

            if (results.next()) {
                ClientsServed = results.getString("ClientsServed");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return ClientsServed;
    }

    public static boolean validateAdmin(String idBank, String password) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT AdminPassword FROM centralbank WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, idBank);
            results = statement.executeQuery();

            if (results.next()) {
                String pass = results.getString("AdminPassword");
                return pass.equals(password);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

        return false;
    }

    public static CentralBank getBankInfo(String idBank) {
        CentralBank bank = null;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;

        try {
            conn = ConnectionDB.getConnectionDB();
            String sql = "SELECT ClientsServed, Withdrawals, Profits, NumClients FROM centralbank WHERE IdBank = ?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, idBank);
            results = statement.executeQuery();

            if (results.next()) {
                bank = new CentralBank();
                bank.setIdBank(idBank);
                bank.setClientsServed(results.getString("ClientsServed"));
                bank.setWithdrawals(results.getDouble("Withdrawals"));
                bank.setProfits(results.getDouble("Profits"));
                bank.setNumClients(results.getInt("NumClients"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }
        return bank;
    }

    public static boolean modifierState(String state, int accountNumber) {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet results = null;
        String State = "valido";
        boolean isValid = true;
        boolean accountExists = false;

        try {
            conn = ConnectionDB.getConnectionDB();

            String checkAccountSql = "SELECT COUNT(*) AS account_count FROM bankaccount WHERE AccountNumber = ?";
            statement = conn.prepareStatement(checkAccountSql);
            statement.setInt(1, accountNumber);
            results = statement.executeQuery();

            if (results.next()) {
                int count = results.getInt("account_count");
                accountExists = count > 0;
            }
            if (!accountExists) {
                return false;
            }

            if (state.equals("valido")) {
                String updateSql = "UPDATE bankaccount SET AccountState = ?, TypeOfState=? WHERE AccountNumber = ?";
                statement = conn.prepareStatement(updateSql);
                statement.setBoolean(1, isValid);
                statement.setString(2, State);
                statement.setInt(3, accountNumber);
            } else {
                isValid = false;
                if (state.equals("embargado")) {
                    String updateSql = "UPDATE bankaccount SET AccountState = ?, TypeOfState=?, Money=? WHERE AccountNumber = ?";
                    statement = conn.prepareStatement(updateSql);
                    statement.setBoolean(1, isValid);
                    statement.setString(2, state);
                    statement.setDouble(3, 0);
                    statement.setInt(4, accountNumber);
                } else {
                    String updateSql = "UPDATE bankaccount SET AccountState = ?, TypeOfState=? WHERE AccountNumber = ?";
                    statement = conn.prepareStatement(updateSql);
                    statement.setBoolean(1, isValid);
                    statement.setString(2, state);
                    statement.setInt(3, accountNumber);
                }
            }

            statement.executeUpdate();

        } catch (SQLException ex) {
            Logger.getLogger(DBInformation.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            closeResources(conn, statement, results);
        }

        return true;
    }

}
