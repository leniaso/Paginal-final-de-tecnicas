/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import java.io.BufferedReader;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.MultipartConfig;
import org.json.JSONObject;

@WebServlet("/api/opera")
@MultipartConfig
public class OperationsServlet extends HttpServlet {

    @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Aquí colocas el código para manejar las solicitudes POST
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader reader = request.getReader();
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        double voucher = 1;
        JSONObject jsonData = new JSONObject(sb.toString());
       
        int accountNumber = jsonData.getInt("accountNumber");
        String operation = jsonData.getString("operation");
        String currency = jsonData.getString("currency");
        double amount = jsonData.getDouble("amount");
        String emergencyPassword = jsonData.optString("emergencyPassword", null);
        String id = DBInformation.getIDByAccNumber(accountNumber);
        String emerPassDB = DBInformation.getEmergencyPassword(id);

        if (operation.equals("retirar")) {
            if (amount <= 20000000) {
            
                voucher = DBInformation.retire(accountNumber, amount, currency);
                if (voucher < 0) {
                    JSONObject errorResponse = new JSONObject();
                    errorResponse.put("message", "Hubo un error y no se pudo realizar la transacción.");
                    PrintWriter out = response.getWriter();
                    out.print(errorResponse);
                    out.flush();
                    return; 
                }
            } else {
              
                if (emergencyPassword != null && emergencyPassword.equals(emerPassDB)) {
                    voucher = DBInformation.retire(accountNumber, amount, currency);
                    if (voucher < 0) {
                        JSONObject errorResponse = new JSONObject();
                        errorResponse.put("message", "Hubo un error y no se pudo realizar la transacción.");
                        PrintWriter out = response.getWriter();
                        out.print(errorResponse);
                        out.flush();
                        return; 
                    }
                } else {
                
                    JSONObject errorResponse = new JSONObject();
                    errorResponse.put("message", "La contraseña de emergencia es incorrecta.");
                    PrintWriter out = response.getWriter();
                    out.print(errorResponse);
                    out.flush();
                    return;
                }
            }
        } else {
            DBInformation.Consign(accountNumber, amount, currency);
        }
        JSONObject jsonResponse = new JSONObject();
        jsonResponse.put("message", "Operación realizada con éxito");
        PrintWriter out = response.getWriter();
        out.print(jsonResponse);
        out.flush();
    }
}